package com.porra.mundial.model;

public enum CompetitionType {
    FIFA_WORLD_CUP_2026,
    PREMIER_LEAGUE,
    CHAMPIONS_LEAGUE
}
