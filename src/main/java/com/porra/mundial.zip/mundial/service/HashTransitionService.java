package com.porra.mundial.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.porra.mundial.dto.BetDataDTO;
import com.porra.mundial.model.*;
import com.porra.mundial.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class HashTransitionService {

    private final ObjectMapper objectMapper = new ObjectMapper();
    private final TeamRepository teamRepository;
    private final BetRepository betRepository;
    private final GroupPredictionRepository groupPredictionRepository;
    private final BracketPredictionRepository bracketPredictionRepository;
    private final ExtraPredictionRepository extraPredictionRepository;

    @Transactional
    public void saveRelationalPredictions(Bet bet, BetDataDTO dto) {
        if (dto == null) return;
        
        try {
            // Clean old predictions for this bet if re-saving
            cleanOldPredictions(bet.getId());

            // Parse Thirds array (which 3rd places advanced)
            Set<String> legacyThirds = new HashSet<>();
            if (dto.getThirds() != null) {
                legacyThirds.addAll(dto.getThirds());
            }

            // 2. Parse Groups (pronosticos_grupo)
            if (dto.getGroups() != null) {
                for (Map.Entry<String, List<String>> entry : dto.getGroups().entrySet()) {
                    String groupName = entry.getKey();
                    List<String> teamsList = entry.getValue();
                    for (int i = 0; i < teamsList.size(); i++) {
                        String teamName = teamsList.get(i);
                        Team team = getTeamByName(teamName);
                        if (team != null) {
                            boolean isBest = legacyThirds.contains(teamName);
                            groupPredictionRepository.save(GroupPrediction.builder()
                                    .bet(bet)
                                    .groupName(groupName)
                                    .team(team)
                                    .position(i + 1)
                                    .isBestThird(isBest)
                                    .build());
                        }
                    }
                }
            }

            // 3. Parse Bracket (pronosticos_cuadro)
            saveBracketPhase(bet, dto.getR16(), "R16", dto.getFlatQf());
            saveBracketPhase(bet, dto.getQf(), "QF", dto.getFlatSf());
            saveBracketPhase(bet, dto.getSf(), "SF", dto.getFinalMatch());
            
            if (dto.getFinalMatch() != null && dto.getFinalMatch().size() == 2) {
                saveBracketSingleMatch(bet, dto.getFinalMatch(), "FINAL", dto.getChampion());
            }
            if (dto.getThirdPlaceMatch() != null && dto.getThirdPlaceMatch().size() == 2) {
                saveBracketSingleMatch(bet, dto.getThirdPlaceMatch(), "THIRD_PLACE", dto.getThirdPlaceWinner());
            }

            // 4. Parse Extra (pronosticos_extra)
            Team championTeam = getTeamByName(dto.getChampion());
            Team thirdPlaceTeam = getTeamByName(dto.getThirdPlaceWinner());

            if (championTeam != null) {
                extraPredictionRepository.save(ExtraPrediction.builder()
                        .bet(bet)
                        .topScorer(dto.getScorer())
                        .championTeam(championTeam)
                        .thirdPlaceTeam(thirdPlaceTeam)
                        .build());
            }

        } catch (Exception e) {
            log.error("Error al guardar predicciones para bet_id=" + bet.getId(), e);
        }
    }

    private void cleanOldPredictions(Long betId) {
        // Find and delete existing predictions for double-write updates
        // To be safe, we just let Cascade Delete handle it or delete manually
        groupPredictionRepository.deleteAll(groupPredictionRepository.findByBetId(betId));
        bracketPredictionRepository.deleteAll(bracketPredictionRepository.findByBetId(betId));
        extraPredictionRepository.findById(betId).ifPresent(extraPredictionRepository::delete);
    }

    private void saveBracketPhase(Bet bet, List<List<String>> phaseArray, String dbPhaseName, List<String> nextPhaseWinners) {
        if (phaseArray == null) return;

        for (int i = 0; i < phaseArray.size(); i++) {
            List<String> match = phaseArray.get(i);
            if (match.size() >= 2) {
                String homeName = match.get(0);
                String awayName = match.get(1);
                Team home = getTeamByName(homeName);
                Team away = getTeamByName(awayName);

                // Find winner by checking if home or away is present in the NEXT phase array
                String winnerName = findWinnerInNextPhaseList(homeName, awayName, nextPhaseWinners);
                Team winner = getTeamByName(winnerName);

                if (winner != null) {
                    bracketPredictionRepository.save(BracketPrediction.builder()
                            .bet(bet)
                            .phase(dbPhaseName)
                            .matchIndex(i)
                            .homeTeam(home)
                            .awayTeam(away)
                            .winnerTeam(winner)
                            .build());
                }
            }
        }
    }

    private void saveBracketSingleMatch(Bet bet, List<String> match, String dbPhaseName, String winnerName) {
        if (match == null || match.size() < 2) return;

        String homeName = match.get(0);
        String awayName = match.get(1);

        Team home = getTeamByName(homeName);
        Team away = getTeamByName(awayName);
        Team winner = getTeamByName(winnerName);

        if (winner != null) {
            bracketPredictionRepository.save(BracketPrediction.builder()
                    .bet(bet)
                    .phase(dbPhaseName)
                    .matchIndex(0)
                    .homeTeam(home)
                    .awayTeam(away)
                    .winnerTeam(winner)
                    .build());
        }
    }

    private String findWinnerInNextPhaseList(String team1, String team2, List<String> nextPhaseWinners) {
        if (nextPhaseWinners == null) return team1; // fallback
        
        for (String t : nextPhaseWinners) {
            if (team1.equals(t)) return team1;
            if (team2.equals(t)) return team2;
        }
        
        return team1; // fallback
    }

    private Team getTeamByName(String name) {
        if (name == null) return null;
        return teamRepository.findByName(name).orElseGet(() -> 
            teamRepository.findByNameEn(name).orElse(null)
        );
    }

    @Transactional(readOnly = true)
    public BetDataDTO rebuildBetDataDtoFromTables(Long betId) {
        BetDataDTO dto = new BetDataDTO();

        // 1. Rebuild Groups
        List<GroupPrediction> groupPreds = groupPredictionRepository.findByBetId(betId);
        Map<String, List<String>> groupsMap = new LinkedHashMap<>();
        for (GroupPrediction gp : groupPreds) {
            groupsMap.putIfAbsent(gp.getGroupName(), new ArrayList<>());
        }
        
        // Sort by position before adding to the list
        groupPreds.sort(Comparator.comparingInt(GroupPrediction::getPosition));
        for (GroupPrediction gp : groupPreds) {
            groupsMap.get(gp.getGroupName()).add(gp.getTeam().getName());
        }
        dto.setGroups(groupsMap);

        // Thirds (the 3rd placed teams that advanced)
        List<String> thirds = new ArrayList<>();
        for (GroupPrediction gp : groupPreds) {
            if (Boolean.TRUE.equals(gp.getIsBestThird())) {
                thirds.add(gp.getTeam().getName());
            }
        }
        dto.setThirds(thirds);

        // 2. Rebuild Bracket
        List<BracketPrediction> bracketPreds = bracketPredictionRepository.findByBetId(betId);
        
        List<List<String>> r16 = buildPhaseArray(bracketPreds, "R16");
        List<List<String>> qf = buildPhaseArray(bracketPreds, "QF");
        List<List<String>> sf = buildPhaseArray(bracketPreds, "SF");

        dto.setR16(r16);
        dto.setQf(qf);
        dto.setSf(sf);

        // Final and Third Place
        BracketPrediction finalMatch = bracketPreds.stream().filter(p -> "FINAL".equals(p.getPhase())).findFirst().orElse(null);
        if (finalMatch != null) {
            dto.setFinalMatch(Arrays.asList(finalMatch.getHomeTeam().getName(), finalMatch.getAwayTeam().getName()));
        }

        BracketPrediction thirdPlace = bracketPreds.stream().filter(p -> "THIRD_PLACE".equals(p.getPhase())).findFirst().orElse(null);
        if (thirdPlace != null) {
            dto.setThirdPlaceMatch(Arrays.asList(thirdPlace.getHomeTeam().getName(), thirdPlace.getAwayTeam().getName()));
        }

        // 3. Rebuild Extra
        ExtraPrediction extra = extraPredictionRepository.findById(betId).orElse(null);
        if (extra != null) {
            dto.setScorer(extra.getTopScorer());
            dto.setChampion(extra.getChampionTeam().getName());
            if (extra.getThirdPlaceTeam() != null) {
                dto.setThirdPlaceWinner(extra.getThirdPlaceTeam().getName());
            }
        }

        return dto;
    }

    private List<List<String>> buildPhaseArray(List<BracketPrediction> allPreds, String phaseName) {
        List<BracketPrediction> phasePreds = allPreds.stream()
                .filter(p -> phaseName.equals(p.getPhase()))
                .sorted(Comparator.comparingInt(BracketPrediction::getMatchIndex))
                .collect(Collectors.toList());

        List<List<String>> result = new ArrayList<>();
        for (BracketPrediction p : phasePreds) {
            String home = p.getHomeTeam() != null ? p.getHomeTeam().getName() : null;
            String away = p.getAwayTeam() != null ? p.getAwayTeam().getName() : null;
            if (home != null && away != null) {
                result.add(Arrays.asList(home, away));
            }
        }
        return result;
    }
}
