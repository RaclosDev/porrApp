package com.porra.mundial.service;

import com.porra.mundial.model.Bet;
import com.porra.mundial.model.BetGroup;
import com.porra.mundial.repository.BetGroupRepository;
import com.porra.mundial.repository.BetRepository;
import com.porra.mundial.repository.UserAccountRepository;
import com.porra.mundial.repository.CompetitionRepository;
import com.porra.mundial.repository.EditionRepository;
import com.porra.mundial.repository.MembershipRepository;
import com.porra.mundial.model.UserAccount;
import com.porra.mundial.model.Competition;
import com.porra.mundial.model.Edition;
import com.porra.mundial.model.Membership;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class GroupService {

    private final BetGroupRepository betGroupRepository;
    private final BetRepository betRepository;
    private final UserAccountRepository userAccountRepository;
    private final CompetitionRepository competitionRepository;
    private final EditionRepository editionRepository;
    private final MembershipRepository membershipRepository;

    @Value("${app.admins:Admin}")
    private List<String> appAdmins;

    @PostConstruct
    @Transactional
    public void initDefaultGroup() {
        UserAccount adminUser = userAccountRepository.findByParticipantName("Admin")
                .orElseGet(() -> userAccountRepository.save(UserAccount.builder()
                        .googleEmail("admin@local")
                        .googleName("Admin")
                        .participantName("Admin")
                        .isSuperadmin(true)
                        .build()));

        BetGroup globalGroup = betGroupRepository.findById(1L).orElse(null);

        if (globalGroup == null) {
            // Find if any group has code GLOBAL
            globalGroup = betGroupRepository.findByJoinCode("GLOBAL").orElse(null);
            if (globalGroup == null) {
                globalGroup = BetGroup.builder()
                        .name("Porra Global")
                        .joinCode("GLOBAL")
                        .adminUser(adminUser)
                        .build();
                globalGroup = betGroupRepository.save(globalGroup);
            }
        } else {
            // Ensure group 1 is named "Porra Global", has joinCode "GLOBAL", and admin is "Admin"
            if (!"GLOBAL".equals(globalGroup.getJoinCode()) || !"Porra Global".equals(globalGroup.getName()) || !adminUser.getId().equals(globalGroup.getAdminUser().getId())) {
                try {
                    // If there's another group with join code GLOBAL, we rename it first to avoid unique constraint violation
                    betGroupRepository.findByJoinCode("GLOBAL").ifPresent(other -> {
                        if (!other.getId().equals(1L)) {
                            log.warn("Found another group with code GLOBAL: id={}. Renaming it to avoid conflict.", other.getId());
                            other.setJoinCode(UUID.randomUUID().toString().substring(0, 6).toUpperCase());
                            betGroupRepository.saveAndFlush(other);
                        }
                    });
                    
                    log.info("Updating existing group 1 to be the Global group (joinCode=GLOBAL, name=Porra Global, adminUser=Admin)");
                    globalGroup.setJoinCode("GLOBAL");
                    globalGroup.setName("Porra Global");
                    globalGroup.setAdminUser(adminUser);
                    globalGroup = betGroupRepository.saveAndFlush(globalGroup);
                } catch (Exception e) {
                    log.error("Failed to update global group, likely due to DB constraints. Error: {}", e.getMessage(), e);
                }
            }
        }

        final BetGroup finalGlobalGroup = globalGroup;

        // Ensure Competition exists
        Competition comp = competitionRepository.findByName("Mundial 2026")
            .orElseGet(() -> competitionRepository.save(Competition.builder()
                    .name("Mundial 2026")
                    .build()));

        // Ensure Edition exists
        Edition edition = editionRepository.findByLeagueIdAndStatus(finalGlobalGroup.getId(), "ACTIVE")
            .orElseGet(() -> editionRepository.save(Edition.builder()
                    .league(finalGlobalGroup)
                    .competition(comp)
                    .betMode(com.porra.mundial.model.BetMode.FULL_BRACKET)
                    .status("ACTIVE")
                    .build()));

        // Ensure Membership for Admin
        Membership.MembershipId memId = new Membership.MembershipId(finalGlobalGroup.getAdminUser().getId(), finalGlobalGroup.getId());
        if (!membershipRepository.existsById(memId)) {
            membershipRepository.save(Membership.builder()
                .id(memId)
                .user(finalGlobalGroup.getAdminUser())
                .league(finalGlobalGroup)
                .role("ADMIN")
                .build());
        }

        // Migrate all existing bets to this global group (except the Admin template)
        List<Bet> allBets = betRepository.findAll();
        boolean migrated = false;
        for (Bet bet : allBets) {
            if (bet.getEdition() == null) {
                if (bet.getParticipantName().equalsIgnoreCase("Admin")) {
                    // Admin bet stays global (null)
                    continue;
                }
                bet.setEdition(edition);
                betRepository.save(bet);
                migrated = true;
            }
        }
        
        if (migrated) {
            log.info("Migradas las porras existentes al Grupo Global.");
        }
    }

    public BetGroup createGroup(String name, String adminParticipantName) {
        String joinCode;
        do {
            joinCode = UUID.randomUUID().toString().substring(0, 6).toUpperCase();
        } while (betGroupRepository.findByJoinCode(joinCode).isPresent());

        UserAccount adminUser = userAccountRepository.findByParticipantName(adminParticipantName)
                .orElseThrow(() -> new IllegalArgumentException("Usuario no encontrado: " + adminParticipantName));

        BetGroup group = BetGroup.builder()
                .name(name)
                .joinCode(joinCode)
                .adminUser(adminUser)
                .build();
        return betGroupRepository.save(group);
    }

    public Optional<BetGroup> getGroupByJoinCode(String joinCode) {
        return betGroupRepository.findByJoinCode(joinCode);
    }

    @Transactional(readOnly = true)
    public List<BetGroup> getUserGroups(String participantName) {
        List<Bet> bets = betRepository.findByUserParticipantName(participantName);
        List<Long> groupIds = bets.stream()
                .map(Bet::getGroupId)
                .filter(id -> id != null)
                .distinct()
                .collect(Collectors.toList());
        
        List<BetGroup> adminGroups = betGroupRepository.findByAdminUserParticipantName(participantName);
        adminGroups.forEach(g -> {
            if (!groupIds.contains(g.getId())) {
                groupIds.add(g.getId());
            }
        });

        return betGroupRepository.findAllById(groupIds);
    }

    public Optional<BetGroup> getGroupById(Long id) {
        return betGroupRepository.findById(id);
    }

    @Transactional
    public void leaveGroup(Long groupId, String participantName) {
        if (groupId == 1L) {
            throw new IllegalArgumentException("No puedes abandonar la Porra Global.");
        }
        BetGroup group = betGroupRepository.findById(groupId)
            .orElseThrow(() -> new java.util.NoSuchElementException("Grupo no encontrado"));

        if (group.getAdminParticipantName().equalsIgnoreCase(participantName)) {
            throw new IllegalArgumentException("El creador de la liga no puede abandonarla.");
        }

        List<Bet> bets = betRepository.findByUserParticipantName(participantName);
        for (Bet bet : bets) {
            if (bet.getGroupId() != null && bet.getGroupId().equals(groupId)) {
                betRepository.delete(bet);
            }
        }
    }

    private void verifyGroupAdmin(Long groupId, String participantName) {
        BetGroup group = betGroupRepository.findById(groupId)
                .orElseThrow(() -> new java.util.NoSuchElementException("Grupo no encontrado"));
                
        boolean isSuperAdmin = appAdmins.stream().anyMatch(admin -> admin.equalsIgnoreCase(participantName));
                               
        if (!isSuperAdmin && !group.getAdminParticipantName().equalsIgnoreCase(participantName)) {
            throw new SecurityException("No tienes permiso para administrar esta liga.");
        }
    }

    @Transactional(readOnly = true)
    public List<Bet> getGroupBetsForAdmin(Long groupId, String participantName) {
        verifyGroupAdmin(groupId, participantName);
        return betRepository.findByEditionLeagueId(groupId);
    }

    @Transactional
    public Bet toggleBetPaymentStatus(Long groupId, Long betId, String participantName, boolean paid) {
        verifyGroupAdmin(groupId, participantName);
        Bet bet = betRepository.findById(betId)
                .orElseThrow(() -> new java.util.NoSuchElementException("Apuesta no encontrada"));
        if (!groupId.equals(bet.getGroupId())) {
            throw new IllegalArgumentException("La apuesta no pertenece a este grupo");
        }
        bet.setPaid(paid);
        return betRepository.save(bet);
    }

    @Transactional
    public void deleteBet(Long groupId, Long betId, String participantName) {
        verifyGroupAdmin(groupId, participantName);
        Bet bet = betRepository.findById(betId)
                .orElseThrow(() -> new java.util.NoSuchElementException("Apuesta no encontrada"));
        if (!groupId.equals(bet.getGroupId())) {
            throw new IllegalArgumentException("La apuesta no pertenece a este grupo");
        }
        betRepository.delete(bet);
    }

}
